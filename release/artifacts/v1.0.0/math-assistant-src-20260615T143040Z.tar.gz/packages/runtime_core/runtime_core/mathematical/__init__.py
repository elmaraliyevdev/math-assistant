"""Mathematical Engine — deterministic statistical analysis of simulation outputs."""

from runtime_core.mathematical.confidence import calculate_rtp_confidence_interval
from runtime_core.mathematical.distribution import calculate_win_distribution
from runtime_core.mathematical.exposure import calculate_exposure_analysis
from runtime_core.mathematical.feature_frequency import calculate_feature_frequencies
from runtime_core.mathematical.hit_frequency import calculate_hit_frequency
from runtime_core.mathematical.jackpot_frequency import calculate_jackpot_frequencies
from runtime_core.mathematical.models import (
    ConfidenceIntervalResult,
    ExposureAnalysisResult,
    FeatureFrequencyResult,
    HitFrequencyResult,
    JackpotFrequencyResult,
    MathematicsReport,
    RTPResult,
    VolatilityResult,
    WinDistributionBucket,
    WinDistributionResult,
)
from runtime_core.mathematical.report import build_mathematics_report
from runtime_core.mathematical.rtp import calculate_rtp
from runtime_core.mathematical.volatility import calculate_volatility

__all__ = [
    "ConfidenceIntervalResult",
    "ExposureAnalysisResult",
    "FeatureFrequencyResult",
    "HitFrequencyResult",
    "JackpotFrequencyResult",
    "MathematicsReport",
    "RTPResult",
    "VolatilityResult",
    "WinDistributionBucket",
    "WinDistributionResult",
    "build_mathematics_report",
    "calculate_exposure_analysis",
    "calculate_feature_frequencies",
    "calculate_hit_frequency",
    "calculate_jackpot_frequencies",
    "calculate_rtp",
    "calculate_rtp_confidence_interval",
    "calculate_volatility",
    "calculate_win_distribution",
]
