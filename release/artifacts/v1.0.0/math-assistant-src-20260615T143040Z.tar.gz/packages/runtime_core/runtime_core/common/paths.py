"""Repository path resolution for schemas and golden fixtures."""

from __future__ import annotations

from pathlib import Path

_REPO_ROOT_MARKER = "tests/golden/manifest.yaml"
_GAME_SCHEMA_MARKER = "packages/game-schema/schemas/game-version-1.0.0.schema.json"


def find_repo_root(*, start: Path | None = None) -> Path:
    """Return the monorepo root containing ``tests/golden/manifest.yaml``.

    Walks upward from *start* (or this file's location) until the marker path exists.
    """
    current = (start or Path(__file__)).resolve()
    if current.is_file():
        current = current.parent
    for candidate in (current, *current.parents):
        if (candidate / _REPO_ROOT_MARKER).is_file():
            return candidate
    msg = f"repository root not found (missing {_REPO_ROOT_MARKER})"
    raise FileNotFoundError(msg)


def golden_fixtures_root(*, repo_root: Path | None = None) -> Path:
    """Path to ``tests/golden/``."""
    root = repo_root or find_repo_root()
    return root / "tests" / "golden"


def game_schema_root(*, repo_root: Path | None = None) -> Path:
    """Path to ``packages/game-schema/``."""
    root = repo_root or find_repo_root()
    schema_root = root / "packages" / "game-schema"
    schema_file = schema_root / "schemas" / "game-version-1.0.0.schema.json"
    if not schema_file.is_file():
        msg = f"game schema not found at {schema_file}"
        raise FileNotFoundError(msg)
    return schema_root
