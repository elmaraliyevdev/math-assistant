"""Schema path resolution for validation."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from runtime_core.common.paths import find_repo_root, game_schema_root


@dataclass(frozen=True, slots=True)
class SchemaPaths:
    game_schema: Path
    plugin_schema_dir: Path


def default_schema_paths(*, repo_root: Path | None = None) -> SchemaPaths:
    """Resolve canonical JSON Schema locations."""
    env_root = os.environ.get("MATH_ASSISTANT_SCHEMA_ROOT")
    if env_root:
        candidate = Path(env_root)
        game_schema = candidate / "schemas" / "game-version-1.0.0.schema.json"
        if game_schema.is_file():
            return SchemaPaths(
                game_schema=game_schema,
                plugin_schema_dir=candidate / "schemas" / "plugins",
            )
    root = game_schema_root(repo_root=repo_root)
    return SchemaPaths(
        game_schema=root / "schemas" / "game-version-1.0.0.schema.json",
        plugin_schema_dir=root / "schemas" / "plugins",
    )


def schema_registry_root(*, repo_root: Path | None = None) -> Path:
    root = repo_root or find_repo_root()
    return root / "packages" / "game-schema"
