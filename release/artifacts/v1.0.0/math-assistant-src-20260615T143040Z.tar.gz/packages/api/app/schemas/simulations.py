"""Simulation API schemas."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class CreateSimulationRequest(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
        json_schema_extra={
            "examples": [
                {
                    "gameVersionId": "660e8400-e29b-41d4-a716-446655440001",
                    "spinCount": 1000,
                    "masterSeed": "cert-benchmark-seed",
                    "eventLogMode": "none",
                    "betMinorUnits": 100,
                },
            ],
        },
    )

    game_version_id: UUID = Field(alias="gameVersionId")
    spin_count: int = Field(alias="spinCount", ge=0)
    master_seed: str | None = Field(default=None, alias="masterSeed")
    event_log_mode: str = Field(default="none", alias="eventLogMode")
    bet_minor_units: int = Field(default=0, alias="betMinorUnits", ge=0)


class CreateSimulationResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    simulation_id: UUID = Field(alias="simulationId")
    status: str


class CancelSimulationResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    simulation_id: UUID = Field(alias="simulationId")
    status: str
    cancel_requested: bool = Field(alias="cancelRequested")


class SimulationProgress(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    completed_spins: int = Field(alias="completedSpins")
    percentage: float


class SimulationSummaryResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    id: UUID
    game_version_id: UUID = Field(alias="gameVersionId")
    status: str
    spin_count: int = Field(alias="spinCount")
    completed_spin_count: int = Field(alias="completedSpinCount")
    created_at: datetime = Field(alias="createdAt")
    completed_at: datetime | None = Field(default=None, alias="completedAt")
    error_message: str | None = Field(default=None, alias="errorMessage")


class SimulationListResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    items: list[SimulationSummaryResponse]
    total: int
    page: int
    page_size: int = Field(alias="pageSize")


class SimulationDetailResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    id: UUID
    game_version_id: UUID = Field(alias="gameVersionId")
    status: str
    spin_count: int = Field(alias="spinCount")
    completed_spin_count: int = Field(alias="completedSpinCount")
    bet_minor_units: int = Field(alias="betMinorUnits")
    event_log_mode: str = Field(alias="eventLogMode")
    created_at: datetime = Field(alias="createdAt")
    started_at: datetime | None = Field(default=None, alias="startedAt")
    completed_at: datetime | None = Field(default=None, alias="completedAt")
    cancel_requested: bool = Field(default=False, alias="cancelRequested")
    worker_id: str | None = Field(default=None, alias="workerId")
    error_message: str | None = Field(default=None, alias="errorMessage")
    progress: SimulationProgress


class SimulationResultsSummary(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    rtp: float
    uncapped_rtp: float = Field(alias="uncappedRtp")
    volatility: float
    hit_frequency: float = Field(alias="hitFrequency")


class SimulationResultsTotals(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    total_bet_minor_units: int = Field(alias="totalBetMinorUnits")
    total_win_minor_units: int = Field(alias="totalWinMinorUnits")


class FeatureFrequencyItem(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    feature_name: str = Field(alias="featureName")
    trigger_count: int = Field(alias="triggerCount")
    frequency: float
    one_in_x: float | None = Field(default=None, alias="oneInX")


class JackpotFrequencyItem(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    jackpot_tier: str = Field(alias="jackpotTier")
    trigger_count: int = Field(alias="triggerCount")
    frequency: float
    one_in_x: float | None = Field(default=None, alias="oneInX")


class ExposureSummary(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    truncation_rate: float = Field(alias="truncationRate")
    total_truncated_minor_units: int = Field(alias="totalTruncatedMinorUnits")
    capped_rtp: float = Field(alias="cappedRtp")
    uncapped_rtp: float = Field(alias="uncappedRtp")
    rtp_difference: float = Field(alias="rtpDifference")


class SimulationResultsResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    simulation_id: UUID = Field(alias="simulationId")
    summary: SimulationResultsSummary
    totals: SimulationResultsTotals
    feature_frequencies: list[FeatureFrequencyItem] = Field(alias="featureFrequencies")
    jackpot_frequencies: list[JackpotFrequencyItem] = Field(alias="jackpotFrequencies")
    exposure: ExposureSummary
