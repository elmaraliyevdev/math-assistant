"""GameVersion ORM model."""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any

from sqlalchemy import ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, CreatedAtMixin, JsonDocument, UUIDPrimaryKeyMixin

if TYPE_CHECKING:
    from app.db.models.game import Game
    from app.db.models.simulation import Simulation


class GameVersion(Base, UUIDPrimaryKeyMixin, CreatedAtMixin):
    __tablename__ = "game_versions"
    __table_args__ = (
        UniqueConstraint("content_hash", name="uq_game_versions_content_hash"),
    )

    game_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("games.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False, unique=True)
    canonical_json: Mapped[dict[str, Any]] = mapped_column(JsonDocument, nullable=False)
    engine_version: Mapped[str] = mapped_column(String(64), nullable=False)

    game: Mapped[Game] = relationship(back_populates="versions")
    simulations: Mapped[list[Simulation]] = relationship(
        back_populates="game_version",
        cascade="all, delete-orphan",
    )
