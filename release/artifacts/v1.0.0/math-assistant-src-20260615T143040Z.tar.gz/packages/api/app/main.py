"""FastAPI application factory."""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from fastapi import FastAPI

from app.config import Settings, get_settings
from app.db.session import create_engine, create_session_factory
from app.exceptions.handlers import register_exception_handlers
from app.jobs.dispatcher import SimulationDispatcher
from app.middleware.body_size_limit import BodySizeLimitMiddleware
from app.middleware.logging import LoggingMiddleware, configure_logging
from app.middleware.metrics import MetricsMiddleware
from app.middleware.request_id import RequestIdMiddleware
from app.middleware.security_headers import SecurityHeadersMiddleware
from app.observability.sentry import init_sentry
from app.security.guards import configure_security_guards
from app.routers import (
    audit,
    auth,
    dashboard,
    engine,
    exports,
    game_versions,
    games,
    health,
    metrics,
    notifications,
    organizations,
    settings as settings_router,
    simulations,
)
from app.services.validation_service import ValidationService

if TYPE_CHECKING:
    from collections.abc import AsyncIterator


@asynccontextmanager
async def _simulation_lifespan(app: FastAPI) -> AsyncIterator[None]:
    cfg: Settings = app.state.settings
    dispatcher = SimulationDispatcher(
        session_factory=app.state.session_factory,
        worker_count=cfg.simulation_worker_count,
    )
    await dispatcher.start()
    app.state.simulation_dispatcher = dispatcher
    try:
        yield
    finally:
        await dispatcher.stop()
        app.state.simulation_dispatcher = None


def create_app(settings: Settings | None = None) -> FastAPI:
    cfg = settings or get_settings()
    configure_logging(log_level=cfg.log_level)
    init_sentry(cfg)
    configure_security_guards(cfg)

    app = FastAPI(
        title=cfg.app_name,
        version="1.0.0",
        debug=cfg.debug,
        lifespan=_simulation_lifespan,
    )
    app.state.settings = cfg
    app.state.validation_service = ValidationService.create()
    db_engine = create_engine(cfg)
    app.state.db_engine = db_engine
    app.state.session_factory = create_session_factory(db_engine)
    register_exception_handlers(app)
    app.add_middleware(MetricsMiddleware)
    app.add_middleware(LoggingMiddleware)
    app.add_middleware(SecurityHeadersMiddleware, settings=cfg)
    app.add_middleware(BodySizeLimitMiddleware, settings=cfg)
    app.add_middleware(RequestIdMiddleware)
    app.include_router(health.router)
    app.include_router(metrics.router)
    app.include_router(engine.router)
    app.include_router(auth.router)
    app.include_router(settings_router.router)
    app.include_router(notifications.router)
    app.include_router(audit.router)
    app.include_router(dashboard.router)
    app.include_router(exports.router)
    app.include_router(organizations.router)
    app.include_router(games.router)
    app.include_router(game_versions.router)
    app.include_router(simulations.router)
    return app


app = create_app()
