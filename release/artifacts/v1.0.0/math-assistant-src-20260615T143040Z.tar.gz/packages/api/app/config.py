"""Application configuration."""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="API_",
        env_file=".env",
        extra="ignore",
    )

    app_name: str = "Math Assistant API"
    debug: bool = False
    log_level: str = "INFO"
    max_recommended_spin_count: int = Field(
        default=10_000_000,
        description="Certified upper bound from Phase 10.5 benchmarks",
    )
    database_url: str = Field(
        default="postgresql+asyncpg://postgres:postgres@localhost:5432/math_assistant",
        description="Async SQLAlchemy database URL (PostgreSQL in production)",
    )
    database_echo: bool = False
    simulation_worker_count: int = Field(
        default=1,
        ge=1,
        description="Number of in-process simulation workers",
    )
    jwt_secret_key: str = Field(
        default="dev-only-change-me-in-production",
        description="Secret key for signing JWT access and refresh tokens",
    )
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = Field(default=15, ge=1)
    jwt_refresh_token_expire_days: int = Field(default=30, ge=1)
    sentry_dsn: str | None = Field(default=None, description="Sentry DSN for error monitoring")
    sentry_environment: str = Field(default="development")
    sentry_traces_sample_rate: float = Field(default=0.1, ge=0.0, le=1.0)
    security_headers_enabled: bool = Field(default=True)
    enable_hsts: bool = Field(
        default=False,
        description="Enable Strict-Transport-Security (set true behind HTTPS)",
    )
    hsts_max_age_seconds: int = Field(default=31_536_000, ge=0)
    max_request_body_bytes: int = Field(
        default=10_485_760,
        ge=1,
        description="Maximum request body size in bytes (default 10 MiB)",
    )
    rate_limit_auth_per_minute: int = Field(
        default=20,
        ge=1,
        description="Per-IP rate limit for auth endpoints per minute",
    )
    brute_force_max_attempts: int = Field(
        default=5,
        ge=1,
        description="Failed login attempts before temporary lockout",
    )
    brute_force_lockout_minutes: int = Field(
        default=15,
        ge=1,
        description="Lockout duration after brute-force threshold",
    )
    metrics_bearer_token: str | None = Field(
        default=None,
        description="Optional bearer token required for GET /metrics",
    )


def get_settings() -> Settings:
    return Settings()
