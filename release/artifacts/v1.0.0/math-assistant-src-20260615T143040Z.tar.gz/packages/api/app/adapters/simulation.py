"""Simulation execution adapter — public runtime_core APIs only."""

from __future__ import annotations

import uuid
from collections.abc import Callable
from dataclasses import dataclass

from runtime_core.domain.game_version import GameVersion
from runtime_core.mathematical import MathematicsReport, build_mathematics_report
from runtime_core.runtime.events import EventLogMode
from runtime_core.runtime.executor import SessionExecutor
from runtime_core.runtime.spin_chain import SpinChainRequest
from runtime_core.simulation import SimulationProfile, SimulationResult, run_simulation

from app.exceptions.simulation import SimulationJobCancelledError


@dataclass(frozen=True, slots=True)
class SimulationExecutionOutcome:
    engine_result: SimulationResult
    mathematics_report: MathematicsReport


def execute_simulation_with_report(
    game: GameVersion,
    profile: SimulationProfile,
    *,
    on_progress: Callable[[int, int], None] | None = None,
    should_cancel: Callable[[], bool] | None = None,
) -> SimulationExecutionOutcome:
    """Run Monte Carlo simulation and build the mathematics report."""
    if should_cancel and should_cancel():
        raise SimulationJobCancelledError

    engine_result = run_simulation(game, profile, max_workers=1)
    if on_progress:
        on_progress(engine_result.spin_count, profile.spin_count)

    if should_cancel and should_cancel():
        raise SimulationJobCancelledError

    spin_wins = _collect_spin_wins(
        game,
        profile,
        on_progress=on_progress,
        should_cancel=should_cancel,
    )
    mathematics_report = build_mathematics_report(
        engine_result,
        spin_wins_minor_units=spin_wins,
    )
    return SimulationExecutionOutcome(
        engine_result=engine_result,
        mathematics_report=mathematics_report,
    )


def build_simulation_profile(
    *,
    simulation_id: uuid.UUID,
    spin_count: int,
    bet_minor_units: int,
    event_log_mode: EventLogMode,
    master_seed: str | None,
    engine_version: str,
) -> SimulationProfile:
    return SimulationProfile(
        spinCount=spin_count,
        shardCount=1,
        masterSeed=master_seed or f"sim-{simulation_id}",
        simulationRunId=str(simulation_id),
        eventLogMode=event_log_mode,
        betMinorUnits=bet_minor_units,
        engineVersion=engine_version,
    )


def _collect_spin_wins(
    game: GameVersion,
    profile: SimulationProfile,
    *,
    on_progress: Callable[[int, int], None] | None = None,
    should_cancel: Callable[[], bool] | None = None,
) -> tuple[int, ...]:
    if profile.spin_count <= 0:
        return ()
    executor = SessionExecutor()
    wins: list[int] = []
    for spin_chain_index in range(profile.spin_count):
        if should_cancel and should_cancel():
            raise SimulationJobCancelledError
        request = SpinChainRequest(
            game=game,
            master_seed=profile.master_seed,
            spin_chain_index=spin_chain_index,
            shard_index=0,
            simulation_run_id=profile.simulation_run_id,
            bet_minor_units=profile.bet_minor_units,
            engine_version=profile.resolved_engine_version(),
            event_log_mode=EventLogMode.NONE,
        )
        result = executor.execute_spin_chain(request)
        wins.append(result.total_win_minor_units)
        if on_progress:
            on_progress(spin_chain_index + 1, profile.spin_count)
    return tuple(wins)
