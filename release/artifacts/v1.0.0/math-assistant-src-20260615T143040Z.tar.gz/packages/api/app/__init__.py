"""Math Assistant FastAPI application."""
