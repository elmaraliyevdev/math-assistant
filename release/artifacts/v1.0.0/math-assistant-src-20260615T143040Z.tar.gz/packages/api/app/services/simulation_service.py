"""Simulation execution and retrieval service."""

from __future__ import annotations

import uuid
from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.context import AuthContext
from app.db.models.organization_member import OrganizationRole
from app.db.models.simulation import Simulation, SimulationStatus
from app.db.repositories.game_repository import GameRepository
from app.db.repositories.game_version_repository import GameVersionRepository
from app.db.repositories.simulation_repository import SimulationRepository
from app.db.repositories.simulation_result_repository import SimulationResultRepository
from app.exceptions.domain import (
    GameVersionReferenceNotFoundError,
    SimulationCancelNotAllowedError,
    SimulationNotFoundError,
    SimulationResultsNotReadyError,
)
from app.jobs.queue import SimulationQueue
from app.jobs.models import SimulationJob
from app.observability.metrics import SIMULATIONS_TOTAL
from app.services.audit_service import AuditService
from app.schemas.simulations import (
    CancelSimulationResponse,
    CreateSimulationRequest,
    CreateSimulationResponse,
    ExposureSummary,
    FeatureFrequencyItem,
    JackpotFrequencyItem,
    SimulationDetailResponse,
    SimulationListResponse,
    SimulationProgress,
    SimulationResultsResponse,
    SimulationResultsSummary,
    SimulationResultsTotals,
    SimulationSummaryResponse,
)


def _progress_for(simulation: Simulation) -> SimulationProgress:
    spin_count = simulation.spin_count
    completed = simulation.completed_spin_count
    if spin_count <= 0:
        percentage = 100.0
    else:
        percentage = min(100.0, (completed / spin_count) * 100.0)
    return SimulationProgress(
        completed_spins=completed,
        percentage=percentage,
    )


def _to_summary(simulation: Simulation) -> SimulationSummaryResponse:
    return SimulationSummaryResponse(
        id=simulation.id,
        game_version_id=simulation.game_version_id,
        status=simulation.status.value,
        spin_count=simulation.spin_count,
        completed_spin_count=simulation.completed_spin_count,
        created_at=simulation.created_at,
        completed_at=simulation.completed_at,
        error_message=simulation.error_message,
    )


def _to_detail(simulation: Simulation) -> SimulationDetailResponse:
    return SimulationDetailResponse(
        id=simulation.id,
        game_version_id=simulation.game_version_id,
        status=simulation.status.value,
        spin_count=simulation.spin_count,
        completed_spin_count=simulation.completed_spin_count,
        bet_minor_units=simulation.bet_minor_units,
        event_log_mode=simulation.event_log_mode,
        created_at=simulation.created_at,
        started_at=simulation.started_at,
        completed_at=simulation.completed_at,
        cancel_requested=simulation.cancel_requested,
        worker_id=simulation.worker_id,
        error_message=simulation.error_message,
        progress=_progress_for(simulation),
    )


@dataclass(frozen=True, slots=True)
class SimulationService:
    simulations: SimulationRepository
    simulation_results: SimulationResultRepository
    game_versions: GameVersionRepository
    games: GameRepository
    queue: SimulationQueue | None = None

    @classmethod
    def from_session(
        cls,
        session: AsyncSession,
        *,
        queue: SimulationQueue | None = None,
    ) -> SimulationService:
        return cls(
            simulations=SimulationRepository(session),
            simulation_results=SimulationResultRepository(session),
            game_versions=GameVersionRepository(session),
            games=GameRepository(session),
            queue=queue,
        )

    async def create_simulation(
        self,
        auth: AuthContext,
        body: CreateSimulationRequest,
    ) -> CreateSimulationResponse:
        game_version = await self.game_versions.get_by_id_for_organizations(
            body.game_version_id,
            auth.organization_ids,
        )
        if game_version is None:
            raise GameVersionReferenceNotFoundError(
                game_version_id=str(body.game_version_id),
            )

        game = await self.games.get_by_id_for_organizations(
            game_version.game_id,
            auth.organization_ids,
        )
        if game is None:
            raise GameVersionReferenceNotFoundError(
                game_version_id=str(body.game_version_id),
            )
        auth.require_role(game.organization_id, OrganizationRole.DEVELOPER)

        simulation = Simulation(
            game_version_id=body.game_version_id,
            status=SimulationStatus.PENDING,
            spin_count=body.spin_count,
            completed_spin_count=0,
            bet_minor_units=body.bet_minor_units,
            event_log_mode=body.event_log_mode,
            master_seed=body.master_seed,
            cancel_requested=False,
            created_by_user_id=auth.user.id,
        )
        await self.simulations.add(simulation)
        SIMULATIONS_TOTAL.labels(status="pending").inc()

        audit = AuditService.from_session(self.simulations._session)
        await audit.record(
            action="simulation.create",
            entity_type="simulation",
            entity_id=simulation.id,
            user_id=auth.user.id,
            organization_id=game.organization_id,
            metadata={"spinCount": body.spin_count},
        )

        if self.queue is not None:
            await self.queue.enqueue(SimulationJob(simulation_id=simulation.id))

        return CreateSimulationResponse(
            simulation_id=simulation.id,
            status=simulation.status.value,
        )

    async def cancel_simulation(
        self,
        auth: AuthContext,
        simulation_id: uuid.UUID,
    ) -> CancelSimulationResponse:
        simulation = await self._require_simulation(auth, simulation_id)
        if simulation.status not in (
            SimulationStatus.PENDING,
            SimulationStatus.RUNNING,
        ):
            raise SimulationCancelNotAllowedError(
                simulation_id=str(simulation_id),
                status=simulation.status.value,
            )

        game_version = await self.game_versions.get_by_id(simulation.game_version_id)
        if game_version is not None:
            game = await self.games.get_by_id_for_organizations(
                game_version.game_id,
                auth.organization_ids,
            )
            if game is not None:
                auth.require_role(game.organization_id, OrganizationRole.DEVELOPER)

        simulation.cancel_requested = True
        await self.simulations.save(simulation)
        return CancelSimulationResponse(
            simulation_id=simulation.id,
            status=simulation.status.value,
            cancel_requested=True,
        )

    async def list_simulations(
        self,
        auth: AuthContext,
        *,
        page: int,
        page_size: int,
        status: str | None,
        game_version_id: uuid.UUID | None,
    ) -> SimulationListResponse:
        parsed_status = _parse_status_filter(status)
        organization_ids = auth.organization_ids
        total = await self.simulations.count_filtered(
            status=parsed_status,
            game_version_id=game_version_id,
            organization_ids=organization_ids,
        )
        items = await self.simulations.search_paginated(
            page=page,
            page_size=page_size,
            status=parsed_status,
            game_version_id=game_version_id,
            organization_ids=organization_ids,
        )
        return SimulationListResponse(
            items=[_to_summary(item) for item in items],
            total=total,
            page=page,
            page_size=page_size,
        )

    async def get_simulation(
        self,
        auth: AuthContext,
        simulation_id: uuid.UUID,
    ) -> SimulationDetailResponse:
        simulation = await self._require_simulation(auth, simulation_id)
        return _to_detail(simulation)

    async def get_simulation_results(
        self,
        auth: AuthContext,
        simulation_id: uuid.UUID,
    ) -> SimulationResultsResponse:
        simulation = await self._require_simulation(auth, simulation_id)
        if simulation.status != SimulationStatus.COMPLETED:
            raise SimulationResultsNotReadyError(
                simulation_id=str(simulation_id),
                status=simulation.status.value,
            )

        result = await self.simulation_results.get_by_simulation_id(simulation_id)
        if result is None:
            raise SimulationResultsNotReadyError(
                simulation_id=str(simulation_id),
                status=simulation.status.value,
            )

        report = result.mathematics_report
        rtp = report["rtp"]
        hit_frequency = report["hitFrequency"]
        volatility = report["volatility"]
        exposure = report["exposure"]
        return SimulationResultsResponse(
            simulation_id=simulation_id,
            summary=SimulationResultsSummary(
                rtp=rtp["rtp"],
                uncapped_rtp=rtp["uncappedRtp"],
                volatility=volatility["standardDeviation"],
                hit_frequency=hit_frequency["hitFrequency"],
            ),
            totals=SimulationResultsTotals(
                total_bet_minor_units=result.total_bet_minor_units,
                total_win_minor_units=result.total_win_minor_units,
            ),
            feature_frequencies=[
                FeatureFrequencyItem.model_validate(item)
                for item in report.get("featureFrequencies", [])
            ],
            jackpot_frequencies=[
                JackpotFrequencyItem.model_validate(item)
                for item in report.get("jackpotFrequencies", [])
            ],
            exposure=ExposureSummary.model_validate(exposure),
        )

    async def _require_simulation(
        self,
        auth: AuthContext,
        simulation_id: uuid.UUID,
    ) -> Simulation:
        simulation = await self.simulations.get_by_id_for_organizations(
            simulation_id,
            auth.organization_ids,
        )
        if simulation is None:
            raise SimulationNotFoundError(simulation_id=str(simulation_id))
        return simulation


def _parse_status_filter(status: str | None) -> SimulationStatus | None:
    if status is None:
        return None
    try:
        return SimulationStatus(status)
    except ValueError as exc:
        msg = f"unsupported status filter {status!r}"
        raise ValueError(msg) from exc
