"""Dashboard aggregate queries."""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.context import AuthContext
from app.db.models.game import Game
from app.db.models.simulation import Simulation, SimulationStatus
from app.db.models.simulation_result import SimulationResult
from app.schemas.platform import DashboardSummaryResponse
from app.services.audit_service import AuditService, _to_audit_response
from app.services.notification_service import (
    NotificationService,
    _to_notification_response,
)


@dataclass(frozen=True, slots=True)
class DashboardService:
    session: AsyncSession

    @classmethod
    def from_session(cls, session: AsyncSession) -> DashboardService:
        return cls(session=session)

    async def get_summary(self, auth: AuthContext) -> DashboardSummaryResponse:
        org_ids = auth.organization_ids

        total_games = int(
            await self.session.scalar(
                select(func.count())
                .select_from(Game)
                .where(Game.organization_id.in_(org_ids)),
            )
            or 0,
        )
        total_simulations = int(
            await self.session.scalar(select(func.count()).select_from(Simulation))
            or 0,
        )
        active_simulations = int(
            await self.session.scalar(
                select(func.count())
                .select_from(Simulation)
                .where(
                    Simulation.status.in_(
                        [SimulationStatus.PENDING, SimulationStatus.RUNNING],
                    ),
                ),
            )
            or 0,
        )
        average_rtp = await self.session.scalar(
            select(func.avg(SimulationResult.rtp)).select_from(SimulationResult),
        )

        notifications = NotificationService.from_session(self.session)
        recent_items, _ = await notifications.notifications.list_for_user(
            auth.user_id,
            notification_type=None,
            unread_only=False,
            page=1,
            page_size=5,
        )

        audit = AuditService.from_session(self.session)
        activity_items, _ = await audit.audit_logs.list_filtered(
            org_ids,
            user_id=None,
            action=None,
            date_from=None,
            date_to=None,
            page=1,
            page_size=5,
        )
        activity_responses = []
        for item in activity_items:
            user = (
                await audit.users.get_by_id(item.user_id)
                if item.user_id is not None
                else None
            )
            activity_responses.append(
                _to_audit_response(
                    item,
                    user.email if user else None,
                    user.full_name if user else None,
                ),
            )

        return DashboardSummaryResponse(
            total_games=total_games,
            total_simulations=total_simulations,
            active_simulations=active_simulations,
            average_rtp=float(average_rtp) if average_rtp is not None else None,
            recent_notifications=[
                _to_notification_response(item) for item in recent_items
            ],
            recent_activity=activity_responses,
        )
