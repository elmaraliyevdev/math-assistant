"""Domain-level API exceptions."""

from __future__ import annotations

from typing import Any


class DomainError(Exception):
    """Base class for structured API domain errors."""

    code: str
    status_code: int

    def __init__(
        self,
        *,
        message: str,
        details: Any | None = None,
    ) -> None:
        self.message = message
        self.details = details
        super().__init__(message)


class GameNotFoundError(DomainError):
    code = "GAME_NOT_FOUND"
    status_code = 404

    def __init__(self, *, game_id: str) -> None:
        super().__init__(
            message=f"game not found: {game_id}",
            details={"gameId": game_id},
        )


class GameVersionNotFoundError(DomainError):
    code = "GAME_VERSION_NOT_FOUND"
    status_code = 404

    def __init__(self, *, game_id: str, version_id: str) -> None:
        super().__init__(
            message=f"game version not found: {version_id}",
            details={"gameId": game_id, "versionId": version_id},
        )


class DuplicateGameVersionError(DomainError):
    code = "DUPLICATE_GAME_VERSION"
    status_code = 409

    def __init__(self, *, content_hash: str, existing_version_id: str) -> None:
        super().__init__(
            message="a game version with this content hash already exists",
            details={
                "contentHash": content_hash,
                "existingVersionId": existing_version_id,
            },
        )


class ValidationFailedError(DomainError):
    code = "VALIDATION_FAILED"
    status_code = 422

    def __init__(
        self,
        *,
        content_hash: str,
        findings: list[dict[str, Any]],
    ) -> None:
        super().__init__(
            message="game validation failed",
            details={
                "contentHash": content_hash,
                "findings": findings,
            },
        )


class GameVersionReferenceNotFoundError(DomainError):
    code = "GAME_VERSION_NOT_FOUND"
    status_code = 404

    def __init__(self, *, game_version_id: str) -> None:
        super().__init__(
            message=f"game version not found: {game_version_id}",
            details={"gameVersionId": game_version_id},
        )


class SimulationNotFoundError(DomainError):
    code = "SIMULATION_NOT_FOUND"
    status_code = 404

    def __init__(self, *, simulation_id: str) -> None:
        super().__init__(
            message=f"simulation not found: {simulation_id}",
            details={"simulationId": simulation_id},
        )


class SimulationResultsNotReadyError(DomainError):
    code = "SIMULATION_RESULTS_NOT_READY"
    status_code = 409

    def __init__(self, *, simulation_id: str, status: str) -> None:
        super().__init__(
            message="simulation results are not available yet",
            details={"simulationId": simulation_id, "status": status},
        )


class SimulationCancelNotAllowedError(DomainError):
    code = "SIMULATION_CANCEL_NOT_ALLOWED"
    status_code = 409

    def __init__(self, *, simulation_id: str, status: str) -> None:
        super().__init__(
            message="simulation cannot be cancelled in its current state",
            details={"simulationId": simulation_id, "status": status},
        )


class UnauthorizedError(DomainError):
    code = "UNAUTHORIZED"
    status_code = 401

    def __init__(self, *, message: str = "authentication required") -> None:
        super().__init__(message=message, details=None)


class InvalidCredentialsError(DomainError):
    code = "INVALID_CREDENTIALS"
    status_code = 401

    def __init__(self) -> None:
        super().__init__(message="invalid email or password", details=None)


class ForbiddenError(DomainError):
    code = "FORBIDDEN"
    status_code = 403

    def __init__(
        self,
        *,
        message: str = "forbidden",
        details: Any | None = None,
    ) -> None:
        super().__init__(message=message, details=details)


class OrganizationNotFoundError(DomainError):
    code = "ORGANIZATION_NOT_FOUND"
    status_code = 404

    def __init__(self, *, organization_id: str) -> None:
        super().__init__(
            message=f"organization not found: {organization_id}",
            details={"organizationId": organization_id},
        )


class OrganizationAccessDeniedError(DomainError):
    code = "ORGANIZATION_ACCESS_DENIED"
    status_code = 404

    def __init__(self, *, organization_id: str) -> None:
        super().__init__(
            message=f"organization not found: {organization_id}",
            details={"organizationId": organization_id},
        )


class DuplicateEmailError(DomainError):
    code = "DUPLICATE_EMAIL"
    status_code = 409

    def __init__(self, *, email: str) -> None:
        super().__init__(
            message="a user with this email already exists",
            details={"email": email},
        )


class DuplicateOrganizationSlugError(DomainError):
    code = "DUPLICATE_ORGANIZATION_SLUG"
    status_code = 409

    def __init__(self, *, slug: str) -> None:
        super().__init__(
            message="an organization with this slug already exists",
            details={"slug": slug},
        )


class UserNotFoundError(DomainError):
    code = "USER_NOT_FOUND"
    status_code = 404

    def __init__(self, *, user_id: str) -> None:
        super().__init__(
            message=f"user not found: {user_id}",
            details={"userId": user_id},
        )


class MemberNotFoundError(DomainError):
    code = "MEMBER_NOT_FOUND"
    status_code = 404

    def __init__(self, *, user_id: str, organization_id: str) -> None:
        super().__init__(
            message="organization member not found",
            details={"userId": user_id, "organizationId": organization_id},
        )


class InvalidTokenError(DomainError):
    code = "INVALID_TOKEN"
    status_code = 401

    def __init__(self, *, message: str = "invalid or expired token") -> None:
        super().__init__(message=message, details=None)


class InactiveUserError(DomainError):
    code = "INACTIVE_USER"
    status_code = 403

    def __init__(self) -> None:
        super().__init__(message="user account is inactive", details=None)


class NotificationNotFoundError(DomainError):
    code = "NOTIFICATION_NOT_FOUND"
    status_code = 404

    def __init__(self, *, notification_id: str) -> None:
        super().__init__(
            message=f"notification not found: {notification_id}",
            details={"notificationId": notification_id},
        )


class RateLimitExceededError(DomainError):
    code = "RATE_LIMIT_EXCEEDED"
    status_code = 429

    def __init__(self) -> None:
        super().__init__(
            message="too many requests; try again later",
            details=None,
        )


class AccountLockedError(DomainError):
    code = "ACCOUNT_LOCKED"
    status_code = 429

    def __init__(self, *, retry_after_seconds: int) -> None:
        super().__init__(
            message="too many failed login attempts; account temporarily locked",
            details={"retryAfterSeconds": retry_after_seconds},
        )
