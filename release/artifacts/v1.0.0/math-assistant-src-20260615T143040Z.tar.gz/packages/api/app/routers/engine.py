"""Engine metadata router."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from app.dependencies import get_engine_service
from app.schemas.engine import EngineVersionResponse
from app.services.engine_service import EngineService

router = APIRouter(prefix="/engine", tags=["engine"])


@router.get("/version", response_model=EngineVersionResponse)
def get_engine_version(
    engine_service: EngineService = Depends(get_engine_service),
) -> EngineVersionResponse:
    return engine_service.engine_version()
