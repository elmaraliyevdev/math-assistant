"""Organization management router."""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, status

from app.auth.dependencies import get_auth_context
from app.auth.context import AuthContext
from app.dependencies import get_organization_service
from app.schemas.organizations import (
    AddOrganizationMemberRequest,
    CreateOrganizationRequest,
    OrganizationListResponse,
    OrganizationMemberResponse,
    OrganizationResponse,
    UpdateOrganizationRequest,
)
from app.services.organization_service import OrganizationService

router = APIRouter(prefix="/organizations", tags=["organizations"])


@router.post(
    "",
    response_model=OrganizationResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_organization(
    body: CreateOrganizationRequest,
    auth: AuthContext = Depends(get_auth_context),
    organization_service: OrganizationService = Depends(get_organization_service),
) -> OrganizationResponse:
    return await organization_service.create_organization(auth, body)


@router.get("", response_model=OrganizationListResponse)
async def list_organizations(
    auth: AuthContext = Depends(get_auth_context),
    organization_service: OrganizationService = Depends(get_organization_service),
) -> OrganizationListResponse:
    return await organization_service.list_organizations(auth)


@router.get("/{organization_id}", response_model=OrganizationResponse)
async def get_organization(
    organization_id: uuid.UUID,
    auth: AuthContext = Depends(get_auth_context),
    organization_service: OrganizationService = Depends(get_organization_service),
) -> OrganizationResponse:
    return await organization_service.get_organization(auth, organization_id)


@router.patch("/{organization_id}", response_model=OrganizationResponse)
async def update_organization(
    organization_id: uuid.UUID,
    body: UpdateOrganizationRequest,
    auth: AuthContext = Depends(get_auth_context),
    organization_service: OrganizationService = Depends(get_organization_service),
) -> OrganizationResponse:
    return await organization_service.update_organization(
        auth,
        organization_id,
        body,
    )


@router.post(
    "/{organization_id}/members",
    response_model=OrganizationMemberResponse,
    status_code=status.HTTP_201_CREATED,
)
async def add_organization_member(
    organization_id: uuid.UUID,
    body: AddOrganizationMemberRequest,
    auth: AuthContext = Depends(get_auth_context),
    organization_service: OrganizationService = Depends(get_organization_service),
) -> OrganizationMemberResponse:
    return await organization_service.add_member(auth, organization_id, body)


@router.delete(
    "/{organization_id}/members/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def remove_organization_member(
    organization_id: uuid.UUID,
    user_id: uuid.UUID,
    auth: AuthContext = Depends(get_auth_context),
    organization_service: OrganizationService = Depends(get_organization_service),
) -> None:
    await organization_service.remove_member(auth, organization_id, user_id)
