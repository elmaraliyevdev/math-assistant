"""Simulation management router."""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query, status

from app.auth.dependencies import get_auth_context
from app.auth.context import AuthContext
from app.dependencies import get_simulation_service
from app.schemas.simulations import (
    CancelSimulationResponse,
    CreateSimulationRequest,
    CreateSimulationResponse,
    SimulationDetailResponse,
    SimulationListResponse,
    SimulationResultsResponse,
)
from app.services.simulation_service import SimulationService

router = APIRouter(prefix="/simulations", tags=["simulations"])


@router.post(
    "",
    response_model=CreateSimulationResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def create_simulation(
    body: CreateSimulationRequest,
    auth: AuthContext = Depends(get_auth_context),
    simulation_service: SimulationService = Depends(get_simulation_service),
) -> CreateSimulationResponse:
    return await simulation_service.create_simulation(auth, body)


@router.post(
    "/{simulation_id}/cancel",
    response_model=CancelSimulationResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def cancel_simulation(
    simulation_id: uuid.UUID,
    auth: AuthContext = Depends(get_auth_context),
    simulation_service: SimulationService = Depends(get_simulation_service),
) -> CancelSimulationResponse:
    return await simulation_service.cancel_simulation(auth, simulation_id)


@router.get("", response_model=SimulationListResponse)
async def list_simulations(
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100, alias="pageSize"),
    status: str | None = Query(default=None),
    game_version_id: uuid.UUID | None = Query(default=None, alias="gameVersionId"),
    auth: AuthContext = Depends(get_auth_context),
    simulation_service: SimulationService = Depends(get_simulation_service),
) -> SimulationListResponse:
    return await simulation_service.list_simulations(
        auth,
        page=page,
        page_size=page_size,
        status=status,
        game_version_id=game_version_id,
    )


@router.get("/{simulation_id}", response_model=SimulationDetailResponse)
async def get_simulation(
    simulation_id: uuid.UUID,
    auth: AuthContext = Depends(get_auth_context),
    simulation_service: SimulationService = Depends(get_simulation_service),
) -> SimulationDetailResponse:
    return await simulation_service.get_simulation(auth, simulation_id)


@router.get("/{simulation_id}/results", response_model=SimulationResultsResponse)
async def get_simulation_results(
    simulation_id: uuid.UUID,
    auth: AuthContext = Depends(get_auth_context),
    simulation_service: SimulationService = Depends(get_simulation_service),
) -> SimulationResultsResponse:
    return await simulation_service.get_simulation_results(auth, simulation_id)
