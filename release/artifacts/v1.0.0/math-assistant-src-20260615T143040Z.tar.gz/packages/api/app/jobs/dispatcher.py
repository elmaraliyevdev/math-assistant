"""Simulation worker dispatcher."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from app.jobs.queue import InMemorySimulationQueue
from app.jobs.worker import SimulationWorker, new_worker_id


class SimulationDispatcher:
    """Starts and stops in-process simulation workers."""

    def __init__(
        self,
        *,
        session_factory: async_sessionmaker[AsyncSession],
        worker_count: int = 1,
    ) -> None:
        self._session_factory = session_factory
        self._worker_count = max(1, worker_count)
        self.queue = InMemorySimulationQueue()
        self._workers: list[SimulationWorker] = []

    async def start(self) -> None:
        if self._workers:
            return
        for _ in range(self._worker_count):
            worker = SimulationWorker(
                worker_id=new_worker_id(),
                queue=self.queue,
                session_factory=self._session_factory,
            )
            await worker.start()
            self._workers.append(worker)

    async def stop(self) -> None:
        for worker in self._workers:
            await worker.stop()
        self._workers.clear()
