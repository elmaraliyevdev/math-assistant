"""Simulation worker loop."""

from __future__ import annotations

import asyncio
import uuid

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from app.jobs.queue import InMemorySimulationQueue
from app.jobs.simulation_jobs import process_simulation_job


class SimulationWorker:
    def __init__(
        self,
        *,
        worker_id: str,
        queue: InMemorySimulationQueue,
        session_factory: async_sessionmaker[AsyncSession],
    ) -> None:
        self.worker_id = worker_id
        self._queue = queue
        self._session_factory = session_factory
        self._task: asyncio.Task[None] | None = None
        self._stopping = False

    async def start(self) -> None:
        if self._task is not None:
            return
        self._stopping = False
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._stopping = True
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def _run(self) -> None:
        while not self._stopping:
            try:
                job = await asyncio.wait_for(self._queue.dequeue(), timeout=0.25)
            except TimeoutError:
                continue
            try:
                await process_simulation_job(
                    self._session_factory,
                    simulation_id=job.simulation_id,
                    worker_id=self.worker_id,
                )
            finally:
                self._queue.task_done()


def new_worker_id() -> str:
    return f"worker-{uuid.uuid4()}"
