"""Simulation job definitions and execution."""

from __future__ import annotations

import asyncio
import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from runtime_core.domain.game_version import GameVersion
from runtime_core.runtime.events import EventLogMode
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from app.adapters.simulation import (
    build_simulation_profile,
    execute_simulation_with_report,
)
from app.db.models.simulation import Simulation, SimulationStatus
from app.db.models.simulation_result import SimulationResult
from app.db.repositories.game_version_repository import GameVersionRepository
from app.db.repositories.simulation_repository import SimulationRepository
from app.db.repositories.simulation_result_repository import SimulationResultRepository
from app.exceptions.simulation import SimulationJobCancelledError
from app.observability.metrics import SIMULATION_DURATION_SECONDS, MetricsTimer
from app.services.platform_events import notify_simulation_finished_by_id

if TYPE_CHECKING:
    from collections.abc import Callable


class _CancelMonitor:
    def __init__(self) -> None:
        self.cancelled = False


async def process_simulation_job(
    session_factory: async_sessionmaker[AsyncSession],
    *,
    simulation_id: uuid.UUID,
    worker_id: str,
) -> None:
    """Execute one simulation job and persist lifecycle updates."""
    with MetricsTimer(SIMULATION_DURATION_SECONDS):
        await _run_simulation_job(session_factory, simulation_id=simulation_id, worker_id=worker_id)


async def _run_simulation_job(
    session_factory: async_sessionmaker[AsyncSession],
    *,
    simulation_id: uuid.UUID,
    worker_id: str,
) -> None:
    async with session_factory() as session:
        simulations = SimulationRepository(session)
        simulation = await simulations.get_by_id(simulation_id)
        if simulation is None:
            return

        if simulation.cancel_requested:
            await _mark_cancelled(simulations, simulation)
            await session.commit()
            return

        if simulation.status != SimulationStatus.PENDING:
            return

        simulation.status = SimulationStatus.RUNNING
        simulation.started_at = datetime.now(tz=UTC)
        simulation.worker_id = worker_id
        simulation.completed_spin_count = 0
        await simulations.save(simulation)
        await session.commit()

    monitor = _CancelMonitor()
    poll_task = asyncio.create_task(
        _poll_cancel_requested(session_factory, simulation_id, monitor),
    )
    try:
        async with session_factory() as session:
            simulations = SimulationRepository(session)
            game_versions = GameVersionRepository(session)
            results = SimulationResultRepository(session)

            simulation = await simulations.get_by_id(simulation_id)
            if simulation is None:
                return

            if simulation.cancel_requested or monitor.cancelled:
                await _mark_cancelled(simulations, simulation)
                await session.commit()
                return

            game_version = await game_versions.get_by_id(simulation.game_version_id)
            if game_version is None:
                simulation.status = SimulationStatus.FAILED
                simulation.error_message = "game version not found"
                await simulations.save(simulation)
                await session.commit()
                return

            try:
                event_log_mode = _parse_event_log_mode(simulation.event_log_mode)
            except ValueError as exc:
                simulation.status = SimulationStatus.FAILED
                simulation.error_message = str(exc)
                await simulations.save(simulation)
                await session.commit()
                return

            profile = build_simulation_profile(
                simulation_id=simulation.id,
                spin_count=simulation.spin_count,
                bet_minor_units=simulation.bet_minor_units,
                event_log_mode=event_log_mode,
                master_seed=simulation.master_seed,
                engine_version=game_version.engine_version,
            )
            game = GameVersion.model_validate(game_version.canonical_json)

            def should_cancel() -> bool:
                return monitor.cancelled

            outcome = await asyncio.to_thread(
                execute_simulation_with_report,
                game,
                profile,
                should_cancel=should_cancel,
            )

            if monitor.cancelled:
                session.expire_all()
                simulation = await simulations.get_by_id(simulation_id)
                if simulation is not None:
                    await _mark_cancelled(simulations, simulation)
                    await session.commit()
                return

            session.expire_all()
            simulation = await simulations.get_by_id(simulation_id)
            if simulation is None:
                return

            if simulation.cancel_requested or monitor.cancelled:
                await _mark_cancelled(simulations, simulation)
                await session.commit()
                return

            report = outcome.mathematics_report
            engine_result = outcome.engine_result
            await results.add(
                SimulationResult(
                    simulation_id=simulation.id,
                    total_bet_minor_units=engine_result.total_bet_minor_units,
                    total_win_minor_units=engine_result.total_win_minor_units,
                    uncapped_win_minor_units=engine_result.uncapped_win_minor_units,
                    rtp=report.rtp.rtp,
                    volatility=report.volatility.standard_deviation,
                    hit_frequency=report.hit_frequency.hit_frequency,
                    mathematics_report=report.model_dump(mode="json", by_alias=True),
                ),
            )

            simulation.status = SimulationStatus.COMPLETED
            simulation.completed_spin_count = simulation.spin_count
            simulation.completed_at = datetime.now(tz=UTC)
            simulation.error_message = None
            await simulations.save(simulation)
            await session.commit()
            await notify_simulation_finished_by_id(session_factory, simulation_id)
    except SimulationJobCancelledError:
        async with session_factory() as session:
            simulations = SimulationRepository(session)
            simulation = await simulations.get_by_id(simulation_id)
            if simulation is not None:
                await _mark_cancelled(simulations, simulation)
                await session.commit()
    except Exception as exc:
        async with session_factory() as session:
            simulations = SimulationRepository(session)
            simulation = await simulations.get_by_id(simulation_id)
            if simulation is not None:
                simulation.status = SimulationStatus.FAILED
                simulation.error_message = str(exc)
                await simulations.save(simulation)
                await session.commit()
                await notify_simulation_finished_by_id(session_factory, simulation_id)
    finally:
        poll_task.cancel()
        try:
            await poll_task
        except asyncio.CancelledError:
            pass


def _progress_callback(
    session_factory: async_sessionmaker[AsyncSession],
    *,
    simulation_id: uuid.UUID,
    loop: asyncio.AbstractEventLoop,
) -> Callable[[int, int], None]:
    async def persist_progress(completed: int) -> None:
        async with session_factory() as progress_session:
            simulations = SimulationRepository(progress_session)
            simulation = await simulations.get_by_id(simulation_id)
            if simulation is not None:
                simulation.completed_spin_count = completed
                await simulations.save(simulation)
                await progress_session.commit()

    def callback(completed: int, total: int) -> None:
        del total
        asyncio.run_coroutine_threadsafe(persist_progress(completed), loop)

    return callback


async def _poll_cancel_requested(
    session_factory: async_sessionmaker[AsyncSession],
    simulation_id: uuid.UUID,
    monitor: _CancelMonitor,
) -> None:
    while not monitor.cancelled:
        async with session_factory() as session:
            simulation = await SimulationRepository(session).get_by_id(simulation_id)
            if simulation is not None and simulation.cancel_requested:
                monitor.cancelled = True
                return
        await asyncio.sleep(0.05)


async def _mark_cancelled(
    simulations: SimulationRepository,
    simulation: Simulation,
) -> None:
    simulation.status = SimulationStatus.FAILED
    simulation.error_message = "Simulation cancelled"
    simulation.completed_at = datetime.now(tz=UTC)
    await simulations.save(simulation)


def _parse_event_log_mode(value: str) -> EventLogMode:
    try:
        return EventLogMode(value)
    except ValueError as exc:
        msg = f"unsupported eventLogMode {value!r}"
        raise ValueError(msg) from exc
