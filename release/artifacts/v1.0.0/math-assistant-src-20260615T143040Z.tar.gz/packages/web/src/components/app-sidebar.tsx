import { Link } from '@tanstack/react-router'
import {
  Building2,
  ClipboardList,
  FlaskConical,
  Gamepad2,
  LayoutDashboard,
  LogOut,
  Settings,
} from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { useLogout } from '@/features/auth/use-auth'
import { cn } from '@/lib/utils'

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/games', label: 'Games', icon: Gamepad2 },
  { to: '/simulations', label: 'Simulations', icon: FlaskConical },
  { to: '/audit', label: 'Audit', icon: ClipboardList },
  { to: '/organizations/settings', label: 'Organization', icon: Building2 },
  { to: '/settings', label: 'Settings', icon: Settings },
] as const

export function AppSidebar({ className }: { className?: string }) {
  const logout = useLogout()

  return (
    <aside
      className={cn(
        'flex h-full w-64 flex-col border-r bg-card/50 p-4',
        className,
      )}
    >
      <div className="mb-6 px-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Math Assistant
        </p>
        <h1 className="text-lg font-bold">Platform</h1>
      </div>

      <nav className="flex flex-1 flex-col gap-1">
        {navItems.map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            className="flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground [&.active]:bg-accent [&.active]:text-accent-foreground"
          >
            <Icon className="h-4 w-4" />
            {label}
          </Link>
        ))}
      </nav>

      <Separator className="my-4" />
      <Button
        variant="ghost"
        className="justify-start"
        onClick={() => logout.mutate()}
      >
        <LogOut className="h-4 w-4" />
        Sign out
      </Button>
    </aside>
  )
}
