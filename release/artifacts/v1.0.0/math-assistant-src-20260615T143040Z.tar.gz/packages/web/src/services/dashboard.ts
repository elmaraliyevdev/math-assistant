import { api } from '@/services/api'
import type { AuditLog } from '@/services/audit'
import type { Notification } from '@/services/notifications'

export interface DashboardSummary {
  totalGames: number
  totalSimulations: number
  activeSimulations: number
  averageRtp: number | null
  recentNotifications: Notification[]
  recentActivity: AuditLog[]
}

export const dashboardApi = {
  getSummary() {
    return api
      .get<DashboardSummary>('/dashboard/summary')
      .then((r) => r.data)
  },
}
