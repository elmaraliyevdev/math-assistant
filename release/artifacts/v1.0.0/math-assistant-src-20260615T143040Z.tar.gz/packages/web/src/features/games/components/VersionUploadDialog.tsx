import { zodResolver } from '@hookform/resolvers/zod'
import { Upload } from 'lucide-react'
import { useRef, useState } from 'react'
import { useForm } from 'react-hook-form'

import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { ValidationFindingsTable } from '@/features/games/components/ValidationFindingsTable'
import {
  DEFAULT_ENGINE_VERSION,
  parseCanonicalJson,
  versionUploadSchema,
  type VersionUploadFormValues,
} from '@/features/games/schemas/game-schemas'
import {
  getDuplicateVersionDetails,
  useCreateGameVersion,
} from '@/features/games/hooks/use-games'
import { getApiErrorCode, getValidationFindings } from '@/lib/api-error'

interface VersionUploadDialogProps {
  gameId: string
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function VersionUploadDialog({
  gameId,
  open,
  onOpenChange,
}: VersionUploadDialogProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)
  const createVersion = useCreateGameVersion(gameId)
  const [uploadError, setUploadError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm<VersionUploadFormValues>({
    resolver: zodResolver(versionUploadSchema),
    defaultValues: {
      engineVersion: DEFAULT_ENGINE_VERSION,
      canonicalJsonText: JSON.stringify({ schemaVersion: '1.0.0' }, null, 2),
    },
  })

  const validationFindings =
    createVersion.isError && getApiErrorCode(createVersion.error) === 'VALIDATION_FAILED'
      ? getValidationFindings(createVersion.error)
      : []

  const duplicateDetails = createVersion.isError
    ? getDuplicateVersionDetails(createVersion.error)
    : null

  function handleClose(nextOpen: boolean) {
    if (!nextOpen) {
      reset()
      createVersion.reset()
      setUploadError(null)
    }
    onOpenChange(nextOpen)
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Upload game version</DialogTitle>
          <DialogDescription>
            Upload a canonical JSON file or paste JSON below. Validation runs before
            the version is saved.
          </DialogDescription>
        </DialogHeader>

        <form
          className="space-y-4"
          onSubmit={handleSubmit((values) => {
            createVersion.mutate({
              canonicalJson: parseCanonicalJson(values.canonicalJsonText),
              engineVersion: values.engineVersion,
            })
          })}
        >
          <div className="flex flex-wrap gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={async (event) => {
                const file = event.target.files?.[0]
                if (!file) return
                try {
                  const text = await file.text()
                  JSON.parse(text)
                  setValue('canonicalJsonText', text, { shouldValidate: true })
                  setUploadError(null)
                } catch {
                  setUploadError('Selected file does not contain valid JSON')
                }
              }}
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="h-4 w-4" />
              Upload JSON file
            </Button>
          </div>
          {uploadError && <p className="text-sm text-destructive">{uploadError}</p>}

          <div className="space-y-2">
            <Label htmlFor="engine-version">Engine version</Label>
            <Input id="engine-version" {...register('engineVersion')} />
            {errors.engineVersion && (
              <p className="text-sm text-destructive">{errors.engineVersion.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="canonical-json">Canonical JSON</Label>
            <Textarea
              id="canonical-json"
              rows={14}
              className="font-mono text-xs"
              {...register('canonicalJsonText')}
            />
            {errors.canonicalJsonText && (
              <p className="text-sm text-destructive">
                {errors.canonicalJsonText.message}
              </p>
            )}
          </div>

          {validationFindings.length > 0 && (
            <div className="space-y-2 rounded-lg border border-destructive/30 bg-destructive/5 p-4">
              <p className="text-sm font-medium text-destructive">
                Validation failed ({validationFindings.length} findings)
              </p>
              <ValidationFindingsTable findings={validationFindings} />
            </div>
          )}

          {duplicateDetails && (
            <p className="text-sm text-amber-700 dark:text-amber-300">
              Duplicate content hash: {duplicateDetails.contentHash}
            </p>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => handleClose(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createVersion.isPending}>
              {createVersion.isPending ? 'Validating…' : 'Create version'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
