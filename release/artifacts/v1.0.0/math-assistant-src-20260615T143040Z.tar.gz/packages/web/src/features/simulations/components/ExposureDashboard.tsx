import { MetricsCards } from '@/features/simulations/components/MetricsCards'
import type { DerivedAnalytics } from '@/features/simulations/types'
import type { SimulationResults } from '@/types/api'
import { formatNumber, formatPercent } from '@/lib/utils'

interface ExposureDashboardProps {
  results: SimulationResults
  analytics: DerivedAnalytics
}

export function ExposureDashboard({
  results,
  analytics,
}: ExposureDashboardProps) {
  const { exposure } = results

  return (
    <MetricsCards
      title="Exposure metrics"
      metrics={[
        {
          label: 'Truncation rate',
          value: formatPercent(exposure.truncationRate),
        },
        {
          label: 'Exposure cap applied',
          value: analytics.exposureCapApplied ? 'Yes' : 'No',
        },
        {
          label: 'Truncated wins',
          value: formatNumber(exposure.totalTruncatedMinorUnits),
        },
        { label: 'Capped RTP', value: formatPercent(exposure.cappedRtp) },
        { label: 'Uncapped RTP', value: formatPercent(exposure.uncappedRtp) },
      ]}
    />
  )
}
