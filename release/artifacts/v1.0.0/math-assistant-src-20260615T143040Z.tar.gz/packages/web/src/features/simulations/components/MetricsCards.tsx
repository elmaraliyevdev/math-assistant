import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { formatNumber, formatPercent } from '@/lib/utils'

interface MetricItem {
  label: string
  value: string
}

interface MetricsCardsProps {
  title: string
  metrics: MetricItem[]
}

export function MetricsCards({ title, metrics }: MetricsCardsProps) {
  return (
    <div className="space-y-3">
      <h3 className="text-lg font-semibold">{title}</h3>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {metrics.map((metric) => (
          <Card key={metric.label}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {metric.label}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold tracking-tight">{metric.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

export function formatMetricPercent(value: number): string {
  return formatPercent(value)
}

export function formatMetricNumber(value: number): string {
  return formatNumber(value)
}
