import type {
  DerivedAnalytics,
  RtpConfidenceInterval,
  WinDistributionBucket,
} from '@/features/simulations/types'
import type { SimulationDetail, SimulationResults } from '@/types/api'

const WIN_BUCKET_LABELS = [
  '0x',
  '0–1x',
  '1–5x',
  '5–10x',
  '10–50x',
  '50–100x',
  '100–500x',
  '500x+',
] as const

const POSITIVE_BUCKET_WEIGHTS = [0.35, 0.28, 0.15, 0.12, 0.06, 0.03, 0.01]

function distributeCounts(total: number, weights: number[]): number[] {
  if (total <= 0) {
    return weights.map(() => 0)
  }

  const raw = weights.map((weight) => weight * total)
  const counts = raw.map((value) => Math.floor(value))
  let remainder = total - counts.reduce((sum, count) => sum + count, 0)

  const ranked = raw
    .map((value, index) => ({ index, fraction: value - counts[index] }))
    .sort((left, right) => right.fraction - left.fraction)

  for (const entry of ranked) {
    if (remainder <= 0) break
    counts[entry.index] += 1
    remainder -= 1
  }

  return counts
}

export function deriveWinningSpins(
  hitFrequency: number,
  spinCount: number,
): number {
  return Math.round(hitFrequency * spinCount)
}

export function deriveCoefficientOfVariation(
  standardDeviation: number,
  meanWinMinorUnits: number,
): number {
  if (meanWinMinorUnits <= 0) {
    return 0
  }
  return standardDeviation / meanWinMinorUnits
}

export function deriveRtpConfidenceInterval(
  rtp: number,
  standardDeviation: number,
  spinCount: number,
  betMinorUnits: number,
  confidenceLevel = 0.95,
): RtpConfidenceInterval {
  const zScore = confidenceLevel >= 0.95 ? 1.96 : 1.645
  const safeBet = Math.max(betMinorUnits, 1)
  const safeSpins = Math.max(spinCount, 1)
  const standardError = standardDeviation / (safeBet * Math.sqrt(safeSpins))

  return {
    rtp,
    lowerBound: Math.max(0, rtp - zScore * standardError),
    upperBound: rtp + zScore * standardError,
    confidenceLevel,
  }
}

export function deriveWinDistribution(
  spinCount: number,
  hitFrequency: number,
  betMinorUnits: number,
  standardDeviation: number,
): WinDistributionBucket[] {
  const safeSpins = Math.max(spinCount, 1)
  const losingSpins = Math.max(0, safeSpins - deriveWinningSpins(hitFrequency, safeSpins))
  const winningSpins = safeSpins - losingSpins

  const volatilityRatio = betMinorUnits > 0 ? standardDeviation / betMinorUnits : 1
  const weights = POSITIVE_BUCKET_WEIGHTS.map((weight, index) =>
    weight * (index < 2 ? 1 : volatilityRatio),
  )
  const weightSum = weights.reduce((sum, weight) => sum + weight, 0) || 1
  const normalizedWeights = weights.map((weight) => weight / weightSum)
  const positiveCounts = distributeCounts(winningSpins, normalizedWeights)

  const counts = [losingSpins, ...positiveCounts]

  return WIN_BUCKET_LABELS.map((label, index) => ({
    label,
    count: counts[index] ?? 0,
    frequency: (counts[index] ?? 0) / safeSpins,
  }))
}

export function deriveAnalytics(
  results: SimulationResults,
  detail: Pick<SimulationDetail, 'spinCount' | 'betMinorUnits'>,
): DerivedAnalytics {
  const { summary, totals, exposure } = results
  const meanWinMinorUnits =
    detail.spinCount > 0 ? totals.totalWinMinorUnits / detail.spinCount : 0
  const standardDeviation = summary.volatility
  const winningSpins = deriveWinningSpins(summary.hitFrequency, detail.spinCount)

  return {
    winningSpins,
    standardDeviation,
    coefficientOfVariation: deriveCoefficientOfVariation(
      standardDeviation,
      meanWinMinorUnits,
    ),
    exposureCapApplied:
      exposure.truncationRate > 0 || exposure.totalTruncatedMinorUnits > 0,
    winDistribution: deriveWinDistribution(
      detail.spinCount,
      summary.hitFrequency,
      detail.betMinorUnits,
      standardDeviation,
    ),
    rtpConfidenceInterval: deriveRtpConfidenceInterval(
      summary.rtp,
      standardDeviation,
      detail.spinCount,
      detail.betMinorUnits,
    ),
  }
}
