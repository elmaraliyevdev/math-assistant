import { zodResolver } from '@hookform/resolvers/zod'
import { useEffect } from 'react'
import { useForm } from 'react-hook-form'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useGameVersions } from '@/features/games/hooks/use-games'
import {
  simulationFormSchema,
  type SimulationFormValues,
} from '@/features/simulations/schemas/simulation-schemas'
import type { Game } from '@/types/api'

interface SimulationFormProps {
  games: Game[]
  defaultValues?: Partial<SimulationFormValues>
  submitLabel?: string
  loading?: boolean
  onSubmit: (values: SimulationFormValues) => void
  onCancel?: () => void
}

export function SimulationForm({
  games,
  defaultValues,
  submitLabel = 'Start simulation',
  loading = false,
  onSubmit,
  onCancel,
}: SimulationFormProps) {
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<SimulationFormValues>({
    resolver: zodResolver(simulationFormSchema),
    defaultValues: {
      gameId: '',
      gameVersionId: '',
      spinCount: 1000,
      betMinorUnits: 100,
      masterSeed: '',
      eventLogMode: 'none',
      ...defaultValues,
    },
  })

  const gameId = watch('gameId')
  const versions = useGameVersions(gameId)

  useEffect(() => {
    if (!gameId) {
      setValue('gameVersionId', '')
      return
    }

    const firstVersion = versions.data?.[0]
    if (firstVersion && !defaultValues?.gameVersionId) {
      setValue('gameVersionId', firstVersion.id)
    }
  }, [defaultValues?.gameVersionId, gameId, setValue, versions.data])

  return (
    <form className="space-y-4" onSubmit={handleSubmit(onSubmit)}>
      <div className="space-y-2">
        <Label htmlFor="sim-game">Game</Label>
        <Select
          value={gameId}
          onValueChange={(value) => {
            setValue('gameId', value, { shouldValidate: true })
            setValue('gameVersionId', '')
          }}
        >
          <SelectTrigger id="sim-game">
            <SelectValue placeholder="Select a game" />
          </SelectTrigger>
          <SelectContent>
            {games.map((game) => (
              <SelectItem key={game.id} value={game.id}>
                {game.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.gameId && (
          <p className="text-sm text-destructive">{errors.gameId.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="sim-version">Game version</Label>
        <Select
          value={watch('gameVersionId')}
          onValueChange={(value) =>
            setValue('gameVersionId', value, { shouldValidate: true })
          }
          disabled={!gameId || versions.isLoading}
        >
          <SelectTrigger id="sim-version">
            <SelectValue placeholder="Select a version" />
          </SelectTrigger>
          <SelectContent>
            {(versions.data ?? []).map((version) => (
              <SelectItem key={version.id} value={version.id}>
                v{version.version}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.gameVersionId && (
          <p className="text-sm text-destructive">
            {errors.gameVersionId.message}
          </p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="sim-spin-count">Spin count</Label>
        <Input
          id="sim-spin-count"
          type="number"
          {...register('spinCount', { valueAsNumber: true })}
        />
        {errors.spinCount && (
          <p className="text-sm text-destructive">{errors.spinCount.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="sim-bet">Bet (minor units)</Label>
        <Input
          id="sim-bet"
          type="number"
          {...register('betMinorUnits', { valueAsNumber: true })}
        />
        {errors.betMinorUnits && (
          <p className="text-sm text-destructive">
            {errors.betMinorUnits.message}
          </p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="sim-seed">Master seed (optional)</Label>
        <Input id="sim-seed" {...register('masterSeed')} />
      </div>

      <div className="space-y-2">
        <Label htmlFor="sim-event-log">Event log mode</Label>
        <Select
          value={watch('eventLogMode')}
          onValueChange={(value: SimulationFormValues['eventLogMode']) =>
            setValue('eventLogMode', value, { shouldValidate: true })
          }
        >
          <SelectTrigger id="sim-event-log">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">None</SelectItem>
            <SelectItem value="summary">Summary</SelectItem>
            <SelectItem value="full">Full</SelectItem>
          </SelectContent>
        </Select>
        {errors.eventLogMode && (
          <p className="text-sm text-destructive">
            {errors.eventLogMode.message}
          </p>
        )}
      </div>

      <div className="flex gap-2">
        <Button type="submit" disabled={loading}>
          {loading ? 'Starting…' : submitLabel}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  )
}
