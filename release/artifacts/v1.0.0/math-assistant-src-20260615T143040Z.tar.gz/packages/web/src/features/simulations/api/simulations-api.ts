import { api } from '@/services/api'
import type {
  SimulationDetail,
  SimulationListResponse,
  SimulationResults,
} from '@/types/api'

import type {
  CreateSimulationInput,
  SimulationListParams,
} from '@/features/simulations/types'

export const simulationsApi = {
  async list(params: SimulationListParams = {}): Promise<SimulationListResponse> {
    const { data } = await api.get<SimulationListResponse>('/simulations', {
      params,
    })
    return data
  },

  async get(simulationId: string): Promise<SimulationDetail> {
    const { data } = await api.get<SimulationDetail>(
      `/simulations/${simulationId}`,
    )
    return data
  },

  async getResults(simulationId: string): Promise<SimulationResults> {
    const { data } = await api.get<SimulationResults>(
      `/simulations/${simulationId}/results`,
    )
    return data
  },

  async create(input: CreateSimulationInput): Promise<{
    simulationId: string
    status: string
  }> {
    const { data } = await api.post<{ simulationId: string; status: string }>(
      '/simulations',
      input,
    )
    return data
  },

  async cancel(simulationId: string): Promise<{
    simulationId: string
    status: string
    cancelRequested: boolean
  }> {
    const { data } = await api.post<{
      simulationId: string
      status: string
      cancelRequested: boolean
    }>(`/simulations/${simulationId}/cancel`)
    return data
  },
}
