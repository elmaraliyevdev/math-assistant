import { MetricsCards } from '@/features/simulations/components/MetricsCards'
import type { DerivedAnalytics } from '@/features/simulations/types'
import type { SimulationResults } from '@/types/api'
import { formatNumber, formatPercent } from '@/lib/utils'

interface VolatilityDashboardProps {
  results: SimulationResults
  analytics: DerivedAnalytics
  spinCount: number
}

export function VolatilityDashboard({
  results,
  analytics,
  spinCount,
}: VolatilityDashboardProps) {
  return (
    <MetricsCards
      title="Volatility metrics"
      metrics={[
        {
          label: 'Volatility (std dev)',
          value: analytics.standardDeviation.toFixed(4),
        },
        {
          label: 'Standard deviation',
          value: analytics.standardDeviation.toFixed(4),
        },
        {
          label: 'Coefficient of variation',
          value: analytics.coefficientOfVariation.toFixed(4),
        },
        {
          label: 'Hit frequency',
          value: formatPercent(results.summary.hitFrequency),
        },
        {
          label: 'Winning spins',
          value: formatNumber(analytics.winningSpins),
        },
        {
          label: 'Total spins',
          value: formatNumber(spinCount),
        },
      ]}
    />
  )
}
