import { Outlet } from '@tanstack/react-router'

import { AppSidebar } from '@/components/app-sidebar'
import { ErrorBoundary } from '@/components/error-boundary'
import {
  OrganizationSwitcher,
  ThemeToggle,
} from '@/components/organization-switcher'
import { NotificationCenter } from '@/features/notifications/components/NotificationCenter'
import { useMe } from '@/features/auth/use-auth'
import { useSyncOrganization } from '@/hooks/use-sync-organization'

export function AppLayout() {
  const { data: me } = useMe()
  useSyncOrganization()

  return (
    <ErrorBoundary>
      <div className="flex min-h-screen bg-background">
        <AppSidebar className="hidden md:flex" />
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="flex items-center justify-between border-b px-4 py-3 md:px-6">
            <div>
              <p className="text-sm text-muted-foreground">Signed in as</p>
              <p className="font-medium">{me?.user.fullName ?? me?.user.email}</p>
            </div>
            <div className="flex items-center gap-2">
              <NotificationCenter />
              <OrganizationSwitcher />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-auto p-4 md:p-6">
            <Outlet />
          </main>
        </div>
      </div>
    </ErrorBoundary>
  )
}
