import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { useMe } from '@/features/auth/use-auth'
import {
  useAddOrganizationMember,
  useCreateOrganization,
  useOrganization,
  useRemoveOrganizationMember,
  useUpdateOrganization,
} from '@/features/organizations/use-organizations'
import { useCurrentOrganization } from '@/hooks/use-sync-organization'
import { getErrorMessage } from '@/services/api'
import { useOrganizationStore } from '@/stores/organization-store'
import type { OrganizationRole } from '@/types/api'

const orgSchema = z.object({
  name: z.string().min(1),
  slug: z
    .string()
    .min(1)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'Use lowercase letters, numbers, and hyphens'),
})

const memberSchema = z.object({
  userId: z.uuid(),
  role: z.enum(['owner', 'admin', 'developer', 'viewer']),
})

type OrgForm = z.infer<typeof orgSchema>
type MemberForm = z.infer<typeof memberSchema>

export function OrganizationSettingsPage() {
  const organizationId = useOrganizationStore((state) => state.currentOrganizationId)
  const currentOrg = useCurrentOrganization()
  const organization = useOrganization(organizationId)
  const { data: me } = useMe()
  const createOrganization = useCreateOrganization()
  const updateOrganization = useUpdateOrganization(organizationId ?? '')
  const addMember = useAddOrganizationMember(organizationId ?? '')
  const removeMember = useRemoveOrganizationMember(organizationId ?? '')

  const orgForm = useForm<OrgForm>({
    resolver: zodResolver(orgSchema),
    values: organization.data
      ? { name: organization.data.name, slug: organization.data.slug }
      : undefined,
  })

  const createOrgForm = useForm<OrgForm>({
    resolver: zodResolver(orgSchema),
    defaultValues: { name: '', slug: '' },
  })

  const memberForm = useForm<MemberForm>({
    resolver: zodResolver(memberSchema),
    defaultValues: { role: 'developer' },
  })

  const canManageMembers =
    currentOrg?.role === 'owner' || currentOrg?.role === 'admin'

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Organization</h2>
        <p className="text-muted-foreground">
          Switch workspaces and manage membership.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your memberships</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {me?.organizations.map((org) => (
            <div
              key={org.organizationId}
              className="flex items-center justify-between rounded-md border p-3"
            >
              <div>
                <p className="font-medium">{org.organizationName}</p>
                <p className="text-sm capitalize text-muted-foreground">{org.role}</p>
              </div>
              {org.organizationId === organizationId && (
                <span className="text-xs font-medium text-primary">Active</span>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {organization.isLoading && <Skeleton className="h-40 w-full" />}

      {organization.data && (
        <Card>
          <CardHeader>
            <CardTitle>Organization settings</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              className="space-y-4"
              onSubmit={orgForm.handleSubmit((values) =>
                updateOrganization.mutate(values),
              )}
            >
              <div className="space-y-2">
                <Label htmlFor="org-name">Name</Label>
                <Input id="org-name" {...orgForm.register('name')} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="org-slug">Slug</Label>
                <Input id="org-slug" {...orgForm.register('slug')} />
              </div>
              {updateOrganization.isError && (
                <p className="text-sm text-destructive">
                  {getErrorMessage(updateOrganization.error)}
                </p>
              )}
              <Button type="submit" disabled={updateOrganization.isPending}>
                Save changes
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Create organization</CardTitle>
        </CardHeader>
        <CardContent>
          <form
            className="grid gap-4 sm:grid-cols-2"
            onSubmit={createOrgForm.handleSubmit((values) =>
              createOrganization.mutate(values, {
                onSuccess: () => createOrgForm.reset(),
              }),
            )}
          >
            <div className="space-y-2">
              <Label htmlFor="new-org-name">Name</Label>
              <Input id="new-org-name" {...createOrgForm.register('name')} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-org-slug">Slug</Label>
              <Input id="new-org-slug" {...createOrgForm.register('slug')} />
            </div>
            {createOrganization.isError && (
              <p className="text-sm text-destructive sm:col-span-2">
                {getErrorMessage(createOrganization.error)}
              </p>
            )}
            <Button type="submit" disabled={createOrganization.isPending}>
              Create organization
            </Button>
          </form>
        </CardContent>
      </Card>

      {canManageMembers && organizationId && (
        <Card>
          <CardHeader>
            <CardTitle>Members</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              className="grid gap-4 md:grid-cols-3"
              onSubmit={memberForm.handleSubmit((values) =>
                addMember.mutate({
                  userId: values.userId,
                  role: values.role as OrganizationRole,
                }),
              )}
            >
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="member-user-id">User ID</Label>
                <Input id="member-user-id" {...memberForm.register('userId')} />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Select
                  value={memberForm.watch('role')}
                  onValueChange={(value) =>
                    memberForm.setValue('role', value as MemberForm['role'])
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="developer">Developer</SelectItem>
                    <SelectItem value="viewer">Viewer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" disabled={addMember.isPending}>
                Add member
              </Button>
            </form>

            <div className="space-y-2">
              {me?.organizations
                .filter((org) => org.organizationId === organizationId)
                .map((org) => (
                  <div
                    key={org.organizationId}
                    className="flex items-center justify-between rounded-md border p-3"
                  >
                    <div>
                      <p className="font-medium">{me.user.fullName}</p>
                      <p className="text-sm text-muted-foreground">{me.user.email}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm capitalize">{org.role}</span>
                      {org.role !== 'owner' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeMember.mutate(me.user.id)}
                        >
                          Remove
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
