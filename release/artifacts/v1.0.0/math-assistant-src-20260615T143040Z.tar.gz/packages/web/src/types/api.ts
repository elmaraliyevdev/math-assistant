export interface User {
  id: string
  email: string
  fullName: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface TokenResponse {
  accessToken: string
  refreshToken: string
  tokenType: string
  expiresIn: number
}

export interface RegisterResponse {
  user: User
  organizationId: string
  tokens: TokenResponse
}

export interface OrganizationMembership {
  organizationId: string
  organizationName: string
  organizationSlug: string
  role: OrganizationRole
}

export type OrganizationRole = 'owner' | 'admin' | 'developer' | 'viewer'

export interface MeResponse {
  user: User
  organizations: OrganizationMembership[]
}

export interface Organization {
  id: string
  name: string
  slug: string
  createdAt: string
  updatedAt: string
}

export interface OrganizationListResponse {
  items: Organization[]
}

export interface OrganizationMember {
  userId: string
  organizationId: string
  role: OrganizationRole
  email?: string | null
  fullName?: string | null
}

export interface Game {
  id: string
  organizationId: string
  name: string
  description: string | null
  createdAt: string
  updatedAt: string
}

export interface GameListResponse {
  items: Game[]
  total: number
  page: number
  pageSize: number
}

export interface GameVersionSummary {
  id: string
  version: number
  contentHash: string
  engineVersion: string
  createdAt: string
}

export interface GameVersionDetail extends GameVersionSummary {
  canonicalJson: Record<string, unknown>
}

export interface CreateGameVersionResponse {
  id: string
  version: number
  contentHash: string
  engineVersion: string
  validationSummary: {
    passed: boolean
    findingCount: number
  }
}

export interface SimulationSummary {
  id: string
  gameVersionId: string
  status: string
  spinCount: number
  completedSpinCount: number
  createdAt: string
  completedAt: string | null
  errorMessage: string | null
}

export interface SimulationListResponse {
  items: SimulationSummary[]
  total: number
  page: number
  pageSize: number
}

export interface SimulationProgress {
  completedSpins: number
  percentage: number
}

export interface SimulationDetail {
  id: string
  gameVersionId: string
  status: string
  spinCount: number
  completedSpinCount: number
  betMinorUnits: number
  eventLogMode: string
  createdAt: string
  startedAt: string | null
  completedAt: string | null
  cancelRequested: boolean
  workerId: string | null
  errorMessage: string | null
  progress: SimulationProgress
}

export interface SimulationResults {
  simulationId: string
  summary: {
    rtp: number
    uncappedRtp: number
    volatility: number
    hitFrequency: number
  }
  totals: {
    totalBetMinorUnits: number
    totalWinMinorUnits: number
  }
  featureFrequencies: Array<{
    featureName: string
    triggerCount: number
    frequency: number
    oneInX: number | null
  }>
  jackpotFrequencies: Array<{
    jackpotTier: string
    triggerCount: number
    frequency: number
    oneInX: number | null
  }>
  exposure: {
    truncationRate: number
    totalTruncatedMinorUnits: number
    cappedRtp: number
    uncappedRtp: number
    rtpDifference: number
  }
}

export interface ApiErrorBody {
  error: {
    code: string
    message: string
  }
}

export interface PaginationParams {
  page?: number
  pageSize?: number
  search?: string
}
