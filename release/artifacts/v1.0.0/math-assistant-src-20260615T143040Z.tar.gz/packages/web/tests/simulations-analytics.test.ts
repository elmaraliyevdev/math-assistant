import { describe, expect, it } from 'vitest'

import {
  deriveAnalytics,
  deriveCoefficientOfVariation,
  deriveRtpConfidenceInterval,
  deriveWinDistribution,
  deriveWinningSpins,
} from '@/features/simulations/utils/analytics'
import type { SimulationDetail, SimulationResults } from '@/types/api'

const results: SimulationResults = {
  simulationId: 'sim-1',
  summary: {
    rtp: 0.96,
    uncappedRtp: 0.97,
    volatility: 4.2,
    hitFrequency: 0.28,
  },
  totals: {
    totalBetMinorUnits: 100_000,
    totalWinMinorUnits: 96_000,
  },
  featureFrequencies: [],
  jackpotFrequencies: [],
  exposure: {
    truncationRate: 0.01,
    totalTruncatedMinorUnits: 100,
    cappedRtp: 0.96,
    uncappedRtp: 0.97,
    rtpDifference: 0.01,
  },
}

const detail: Pick<SimulationDetail, 'spinCount' | 'betMinorUnits'> = {
  spinCount: 1000,
  betMinorUnits: 100,
}

describe('simulation analytics', () => {
  it('derives winning spins from hit frequency', () => {
    expect(deriveWinningSpins(0.28, 1000)).toBe(280)
  })

  it('derives coefficient of variation', () => {
    expect(deriveCoefficientOfVariation(10, 5)).toBe(2)
    expect(deriveCoefficientOfVariation(10, 0)).toBe(0)
  })

  it('derives RTP confidence interval bounds', () => {
    const interval = deriveRtpConfidenceInterval(0.96, 4.2, 1000, 100)
    expect(interval.lowerBound).toBeLessThan(interval.rtp)
    expect(interval.upperBound).toBeGreaterThan(interval.rtp)
    expect(interval.confidenceLevel).toBe(0.95)
  })

  it('builds win distribution buckets', () => {
    const buckets = deriveWinDistribution(1000, 0.28, 100, 4.2)
    expect(buckets).toHaveLength(8)
    expect(buckets[0]?.label).toBe('0x')
    const total = buckets.reduce((sum, bucket) => sum + bucket.count, 0)
    expect(total).toBe(1000)
  })

  it('handles zero spin edge cases', () => {
    const buckets = deriveWinDistribution(0, 0, 100, 4.2)
    expect(buckets).toHaveLength(8)
    expect(deriveWinningSpins(0.5, 0)).toBe(0)
  })

  it('derives full analytics payload', () => {
    const analytics = deriveAnalytics(results, detail)
    expect(analytics.winningSpins).toBe(280)
    expect(analytics.exposureCapApplied).toBe(true)
    expect(analytics.winDistribution).toHaveLength(8)
    expect(analytics.rtpConfidenceInterval.rtp).toBe(0.96)
  })
})
