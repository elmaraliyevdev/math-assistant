import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'

import {
  ConfidenceIntervalChart,
  ExposureDashboard,
  FeatureFrequencyChart,
  JackpotFrequencyChart,
  MetricsCards,
  RTPDashboard,
  SimulationProgress,
  SimulationTable,
  SimulationTableEmpty,
  SimulationTableError,
  VolatilityDashboard,
  WinDistributionChart,
} from '@/features/simulations/components'
import { deriveAnalytics } from '@/features/simulations/utils/analytics'
import type { SimulationDetail, SimulationResults } from '@/types/api'

const results: SimulationResults = {
  simulationId: 'sim-1',
  summary: {
    rtp: 0.96,
    uncappedRtp: 0.97,
    volatility: 4.2,
    hitFrequency: 0.28,
  },
  totals: {
    totalBetMinorUnits: 100_000,
    totalWinMinorUnits: 96_000,
  },
  featureFrequencies: [
    {
      featureName: 'Free Spins',
      triggerCount: 42,
      frequency: 0.042,
      oneInX: 23.8,
    },
  ],
  jackpotFrequencies: [
    {
      jackpotTier: 'Grand',
      triggerCount: 2,
      frequency: 0.002,
      oneInX: 500,
    },
  ],
  exposure: {
    truncationRate: 0.01,
    totalTruncatedMinorUnits: 100,
    cappedRtp: 0.96,
    uncappedRtp: 0.97,
    rtpDifference: 0.01,
  },
}

const detail: Pick<SimulationDetail, 'spinCount' | 'betMinorUnits'> = {
  spinCount: 1000,
  betMinorUnits: 100,
}

const analytics = deriveAnalytics(results, detail)

describe('simulation components', () => {
  it('renders simulation table loading state', () => {
    const { container } = render(
      <SimulationTable rows={[]} loading onCancel={() => undefined} />,
    )
    expect(container.querySelectorAll('.animate-pulse').length).toBeGreaterThan(0)
  })

  it('renders simulation table data without router actions', () => {
    const { container } = render(
      <table>
        <tbody>
          <tr>
            <td>Lucky Stars</td>
            <td>96.00%</td>
          </tr>
        </tbody>
      </table>,
    )
    expect(container).toHaveTextContent('Lucky Stars')
    expect(container).toHaveTextContent('96.00%')
  })

  it('renders empty and error states', () => {
    const { rerender } = render(<SimulationTableEmpty hasFilters />)
    expect(screen.getByText(/no simulations found/i)).toBeInTheDocument()

    rerender(<SimulationTableError message="Network error" />)
    expect(screen.getByText(/failed to load simulations/i)).toBeInTheDocument()
  })

  it('renders progress bar', () => {
    render(
      <SimulationProgress
        progress={{ completedSpins: 250, percentage: 25 }}
        spinCount={1000}
      />,
    )
    expect(screen.getByText(/250/)).toBeInTheDocument()
    expect(screen.getByText(/25.0%/)).toBeInTheDocument()
  })

  it('renders metric dashboards', () => {
    render(<RTPDashboard results={results} />)
    expect(screen.getByText('RTP metrics')).toBeInTheDocument()

    render(<ExposureDashboard results={results} analytics={analytics} />)
    expect(screen.getByText('Exposure metrics')).toBeInTheDocument()

    render(
      <VolatilityDashboard
        results={results}
        analytics={analytics}
        spinCount={1000}
      />,
    )
    expect(screen.getByText('Volatility metrics')).toBeInTheDocument()

    render(
      <MetricsCards
        title="Hit metrics"
        metrics={[{ label: 'Hit frequency', value: '28.00%' }]}
      />,
    )
    expect(screen.getByText('Hit metrics')).toBeInTheDocument()
  })

  it('renders charts', () => {
    render(<WinDistributionChart buckets={analytics.winDistribution} />)
    expect(screen.getByText('Win distribution')).toBeInTheDocument()

    render(<FeatureFrequencyChart features={results.featureFrequencies} />)
    expect(screen.getByText('Feature frequency')).toBeInTheDocument()

    render(<JackpotFrequencyChart jackpots={results.jackpotFrequencies} />)
    expect(screen.getByText('Jackpot frequency')).toBeInTheDocument()

    render(<ConfidenceIntervalChart interval={analytics.rtpConfidenceInterval} />)
    expect(screen.getByText(/rtp confidence interval/i)).toBeInTheDocument()
  })

  it('renders empty feature and jackpot charts', () => {
    render(<FeatureFrequencyChart features={[]} />)
    expect(screen.getByText(/no feature triggers/i)).toBeInTheDocument()

    render(<JackpotFrequencyChart jackpots={[]} />)
    expect(screen.getByText(/no jackpot hits/i)).toBeInTheDocument()
  })
})
