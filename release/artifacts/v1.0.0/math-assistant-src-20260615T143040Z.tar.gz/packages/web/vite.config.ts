import path from 'node:path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vitest/config'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
        rewrite: (requestPath) => requestPath.replace(/^\/api/, ''),
      },
    },
  },
  test: {
    environment: 'jsdom',
    setupFiles: ['./tests/setup.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json-summary'],
      include: [
        'src/features/notifications/**/*.{ts,tsx}',
        'src/features/audit/**/*.{ts,tsx}',
        'src/features/settings/**/*.{ts,tsx}',
        'src/features/dashboard/**/*.{ts,tsx}',
        'src/features/exports/**/*.{ts,tsx}',
        'src/services/notifications.ts',
        'src/services/audit.ts',
        'src/services/settings.ts',
        'src/services/dashboard.ts',
        'src/services/exports.ts',
        'src/pages/audit/**/*.{ts,tsx}',
        'src/pages/settings/**/*.{ts,tsx}',
        'src/pages/dashboard/**/*.{ts,tsx}',
        'src/lib/export.ts',
      ],
      exclude: [
        'src/main.tsx',
        'src/vite-env.d.ts',
        'src/components/ui/dialog.tsx',
        'src/components/ui/confirm-dialog.tsx',
        'src/lib/sentry.ts',
      ],
      thresholds: {
        lines: 85,
        statements: 85,
        functions: 82,
        branches: 75,
      },
    },
  },
})
